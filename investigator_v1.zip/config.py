
import os
import json

from requests.api import head
from urllib3.util import Retry
from requests.adapters import HTTPAdapter
import requests
138978

wf_API = None
vt_API = None
ha_API = None
DEFAULT_TIMEOUT = 5


class TimeoutHTTPAdapter(HTTPAdapter):
    def __init__(self, *args, **kwargs):
        self.timeout = DEFAULT_TIMEOUT
        if "timeout" in kwargs:
            self.timeout = kwargs["timeout"]
            del kwargs["timeout"]
        super().__init__(*args, **kwargs)

    def send(self, request, **kwargs):
        timeout = kwargs.get("timeout")
        if timeout is None:
            kwargs["timeout"] = self.timeout
        return super().send(request, **kwargs)


# setup config
BASE_PATH = os.path.dirname(os.path.realpath(__file__))
try:
    with open('config.json', 'rb') as f:
        configuration = json.load(f)
    vt_API = configuration['vt_api_key']
    wf_API = configuration['wf_api_key']
    ha_API = configuration['ha_api_key']
    urlscan_API = configuration['urlscan_api_key']
except FileNotFoundError:
    print("Using default API keys, if you want to use your own please make a config file.")
    vt_API = 'dc66c18f6fb5d1bb01ae716db7f09c6b6ca790c4b23a55b09397ce0a6f26f05f'
    wf_API = '52fd6379ee726fdd870b006985d235a5'
    ha_API = 'ev1ysgeaf56992a5bq82qg5l809e27fetmtkjifpbe02cc055l8b73uc3b46d27e'

    # print("No config found so I'll make one for you, please enter your API keys")
    # vt_API = input("Virus Total: ")
    # wf_API = input("Wildfire API: ")
    # ha_API = input("Hybrid Analysis: ")
    # urlscan_API = input("urlscan_API")
    # with open("config.json", 'w') as outfile:
    #     json.dump({
    #         'vt_api_key': vt_API,
    #         'wf_api_key': wf_API,
    #         'ha_api_key': ha_API,
    #         'urlscan_api_key': urlscan_API
    #     }, outfile)

    # print("config.json created, if you need to change your keys you can find your config in {}\\config.json".format(BASE_PATH))
except Exception as e:
    print("Config exists but couldn't read it {}".format(e))


retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "POST", "PUT"],
    backoff_factor=2
)

adapter = HTTPAdapter(max_retries=retry_strategy)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)

to_adapter = TimeoutHTTPAdapter(timeout=2.5)
http.mount("https://", to_adapter)
http.mount("http://", to_adapter)

assert_status_hook = lambda response,  \
    *args, **kwargs: response.raise_for_status()

http.hooks["response"] = [assert_status_hook]

# ha_API = config['ha_api_key']


# def configure():
#     BASE_PATH = os.path.dirname(os.path.realpath(__file__))
#     global vt_API
#     global wf_API
#     if not os.path.exists('config.json'):
#         create_config = None
#         while create_config == None:
#             create_config = input("Did not detect a configuration file, would you like me to help you create one? (y/n): ")


#             if create_config.lower == 'y':
#                 while vt_API==None or vt_API == '':
#                     vt_API = input("Please enter your Virus total API key: ")
#                 while wf_API==None or wf_API == '':
#                     wf_API = input("Please enter your Wildfire API key: ")
#                 keys = {
#                     'vt_api_key': wf_API,
#                     'wf_api_key': wf_API
#                 }
#                 with open('config.json', 'w') as config_file:
#                     json.dump(keys, config_file)
#                 return

#             elif create_config.lower == 'n':
#                 print("I'll need API keys to work, these will persist only for the duration of this session")
#                 while vt_API==None or vt_API == '':
#                     vt_API = input("Please enter your Virus total API key: ")
#                 while wf_API==None or wf_API == '':
#                     wf_API = input("Please enter your Wildfire API key: ")
#                 return
#     else:
#         with open('config.json', 'rb') as f:
#                 config = json.load(f)
#         vt_API = config.get('vt_api_key')
#         wf_API = config.get('wf_api_key')
